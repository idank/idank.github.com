# tokenizer for a simple expression evaluator for OUXML

import sys
import ply.lex as lex

states = (
   ('comment','exclusive'),
)

# List of token names, this is mandatory
tokens = (
   'start_OUXML',
   'end_OUXML',
   'date',
   'new_line',
   'inner_text',
   'start_course',
   'course_number',
   'semester',
   'end_course',
   'start_comment',
   'end_comment',
   'start_OU_student',
   'student_name',
   'number_of_points',
   'end_OU_student',
   'start_account',
   'bank_data',
   'end_account',
   'skip_comment'
)

# Regular expression rules for simple tokens
t_start_OUXML = r'(?i)<ouxml'
t_end_OUXML = r'(?i)</ouxml>'
t_new_line = r'(?i)<nl>'
t_start_course = r'(?i)<course'
t_end_course = r'(?i)</course>'
t_start_OU_student = r'(?i)<oustudent'
t_end_OU_student = r'(?i)</oustudent>'
t_start_account = r'(?i)<acc'
t_end_account = r'(?i)</acc>'
t_inner_text = r'[^<>]+'

def t_date(t):
   r'(?i)date=\"\d{1,2}\ (jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\ \d{4}\">'
   t.attributes = {}
   t.attributes['date'] = t.value[6:-2]
   return t

def t_course_number(t):
   r'number=\d+'
   t.attributes = {}
   t.attributes['number'] = t.value[7:]
   return t

def t_semester(t):
   r'(?i)semester=\"\d{4}[abc]\">'
   t.attributes = {}
   t.attributes['semester'] = t.value[10:-2]
   return t

def t_start_comment(t):
   r'<!--'
   t.lexer.begin('comment')

def t_comment_skip_comment(t):
   r'[^"-->"]+'

def t_comment_end_comment(t):
   r'-->'
   t.lexer.begin('INITIAL')

def t_student_name(t):
   r'name=\"[a-zA-Z\ ]+\"'
   t.attributes = {}
   t.attributes['name'] = t.value[6:-2]
   return t

def t_number_of_points(t):
   r'number_of_points=\d+>'
   t.attributes = {}
   t.attributes['number_of_points'] = t.value[17:-1]
   return t

def t_bank_data(t):
   r'bank=\"[a-zA-Z]+\"\ number=\d+>'
   t.attributes = {}
   i = t.value.find('number')
   t.attributes['bank'] = t.value[6:i-2]
   t.attributes['account number'] = t.value[i+7:-1]
   return t

# this rule helps with line numbers
def t_newline(t):
   r'\n+'
   t.lexer.lineno += len(t.value)

# we ignore these characters when parsing (spaces and tabs)
t_ignore  = ' \t'
t_comment_ignore = ' \t'

# error handling
def t_error(t):
   print >>sys.stderr, "bad character '%s'" % t.value[0], "on line:", t.lineno
   t.lexer.skip(1)

def t_comment_error(t):
   print >>sys.stderr, "bad character '%s'" % t.value[0], "on line:", t.lineno
   t.lexer.skip(1)

def write1(f, k, v):
   f.write('%s:%s\n' % (k, v))

def write2(f, k, v):
   f.write('%s:%-55s\n' % (k, v))

if __name__ == "__main__":
   lexer = lex.lex()
   if sys.argv[1].split('.')[-1].lower() != 'ouxml':
      print >>sys.stderr, 'wrong file extension'
      sys.exit(1)

   with open(sys.argv[1], 'r') as f:
      lexer.input(f.read())

   with open('output.tok', 'w') as f:
      f.write('%-20s %-35s %s\n' % ('TOKEN', 'LEXEME', 'ATTRIBUTES'))

      while True:
         tok = lexer.token()
         if not tok: break      # No more input
         f.write('%-20s %-35s' % (tok.type, tok.value))
         if hasattr(tok, 'attributes'):
            white_spaces = len(tok.attributes)
            for k, v in tok.attributes.iteritems():
               white_spaces -= 1
               f.write('%s:%s\n' % (k, v))
               if white_spaces:
                  f.write(' '*56)
         else:
            f.write('\n')
