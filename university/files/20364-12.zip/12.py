import sys
import ply.lex as lex

lst_file = open('output.lst', 'w')

states = (
    ('comment','exclusive'),
)

# List of token names.
tokens = (
    'do',
    'for',
    'if',
    'int',
    'ival',
    'then',
    'otherwise',
    'print',
    'procedure',
    'real',
    'read',
    'rval',
    'variable',
    'while',
    'start_comment',
    'end_comment',
    'left_bracket',
    'right_bracket',
    'left_curly_bracket',
    'right_curly_bracket',
    'comma',
    'colon',
    'semicolon',
    'exclamation_mark',
    'id',
    'num',
    'relop',
    'addop',
    'mulop',
    'assignop',
    'orop',
    'andop'
)

# Regular expression rules for simple tokens
t_do = r'do'
t_for = r'for'
t_if = r'if'
t_int = r'int'
t_ival = r'ival'
t_then = r'then'
t_otherwise = r'otherwise'
t_print = r'print'
t_procedure = r'procedure'
t_real = r'real'
t_read = r'read'
t_rval = r'rval'
t_variable = r'variable'
t_while = r'while'
t_left_bracket = r'\('
t_right_bracket = r'\)'
t_left_curly_bracket = r'{'
t_right_curly_bracket = r'}'
t_comma = r','
t_colon = r':'
t_semicolon = r';'
t_exclamation_mark = r'!'
t_num = r'\d+\.?\d+'
t_relop = r'==|!=|>=|<=|<|>'
t_addop = r'\+|-'
t_mulop = r'\*|/'
t_assignop = r':='
t_orop = r'or'
t_andop = r'and'

def t_id(t):
    r'[a-zA-Z]+([a-zA-Z]|\d)*'
    if t.value in ['do', 'for', 'if', 'int', 'real', 'ival', 'then', 'otherwise', 'print',
                   'procedure', 'read', 'rval', 'variable', 'while']:
        t.type = t.value
    return t

def t_start_comment(t):
    r'/\*'
    t.lexer.begin('comment')

def t_comment_end_comment(t):
    r'.+\*/'
    t.lexer.begin('INITIAL')

# Define a rule so we can track line numbers
def t_newline(t):
    r'\n+'
    t.lexer.lineno += len(t.value)

# A string containing ignored characters (spaces and tabs)
t_ignore  = ' \t'
t_comment_ignore = ' \t'

# Error handling rule
def t_error(t):
    lst_file.write("Illegal character '%s', line: %s\n" % (t.value[0], t.lineno))
    t.lexer.skip(1)

def t_comment_error(t):
    pass

if __name__ == "__main__":
    lexer = lex.lex()
    input_file_name = sys.argv[1]
    if input_file_name.split('.')[-1] not in ['cpl', 'CPL']:
        print 'wrong file extension'
        exit(1)

    with open(sys.argv[1], 'r') as f:
	input_data = f.read()
	lst_file.write(input_data)
	lst_file.write('\n')
    lexer.input(input_data)

    with open('output.tok', 'w') as f:
        f.write('%-20s %s\n' % ('TOKEN', 'VALUE'))
        while True:
            tok = lexer.token()
            if not tok: break      # No more input
            f.write('%-20s %s\n' % (tok.type, tok.value))

    lst_file.close()
