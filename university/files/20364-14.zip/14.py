import sys
import ply.lex as lex
import ply.yacc as yacc

# tokens
tokens = [
   'LEFT_BRACKET',
   'RIGHT_BRACKET',
   'LEFT_PARENTHESIS',
   'RIGHT_PARENTHESIS',
   'COMMA',
   'NUM',
   'ADD',
   'RCONC',
   'SECOND',
   'LAST'
]

# regular expressions
t_LEFT_BRACKET = r'\['
t_RIGHT_BRACKET = r'\]'
t_LEFT_PARENTHESIS = r'\('
t_RIGHT_PARENTHESIS = r'\)'
t_COMMA = r','
t_ADD = r'add'
t_RCONC = r'rconc'
t_SECOND = r'second'
t_LAST = 'last'

def t_NUM(t):
   r'\d+'
   try:
      t.value = int(t.value)
   except ValueError:
      print "integer overflow:", t.value
      t.value = 0
   return t

# ignore these when parsing
t_ignore  = ' \t'

# error handler
def t_error(t):
   lst_file.write("illegal character %r, line: %s\n" % (t.value[0], t.lineno))
   t.lexer.skip(1)

def is_sorted(l):
   return l == sorted(l)

def avg(l):
   return float(reduce(lambda x, y: x + y, l)) / len(l)

def p_s(p):
   's : l'
   ll = p[1]
   if is_sorted(ll):
      print 'The list is sorted:', ll
   else:
      print 'The list is not sorted'
   print 'The average is:', avg(ll)

def p_l1(p):
   'l : LEFT_BRACKET numlist RIGHT_BRACKET'
   p[0] = p[2]

def p_l2(p):
   'l : ADD LEFT_PARENTHESIS item COMMA l RIGHT_PARENTHESIS'
   p[0] = [p[3]] + p[5]

def p_l3(p):
   'l : RCONC LEFT_PARENTHESIS item COMMA l RIGHT_PARENTHESIS'
   p[0] = p[5] + [p[3]]

def p_numlist1(p):
   'numlist : numlist COMMA item'
   p[0] = p[1] + [p[3]]

def p_numlist2(p):
   'numlist : item'
   p[0] = [p[1]]

def p_item1(p):
   'item : NUM'
   p[0] = p[1]

def second(l):
   try:
      return l[1]
   except IndexError:
      return l[0]

def p_item2(p):
   'item : SECOND LEFT_PARENTHESIS l RIGHT_PARENTHESIS'
   p[0] = second(p[3])

def p_item3(p):
   'item : LAST LEFT_PARENTHESIS l RIGHT_PARENTHESIS'
   p[0] = p[3][len(p[3]) - 1]

# error handler
def p_error(p):
   print "Syntax error in input!"

# build the lexer
lex.lex()

# build the parser
parser = yacc.yacc()

input_ = 'rconc(second([2 , 3]) , add(second([4, last([5 , 6]), 7]) , [8 , 9] ) )'
input_ = '[1,2,3]'
input_ = '[1,4,3]'

if __name__ == "__main__":
   with open(sys.argv[1], 'r') as f:
      input_data = f.read()

   parser.parse(input_data)
