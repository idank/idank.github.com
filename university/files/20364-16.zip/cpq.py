#!/usr/bin/env python

__doc__ = 'CPL compiler to QUAD'
__author__ = 'Idan Kamara <idankk86@gmail.com>'

import sys, os
import ply.lex as lex
import ply.yacc as yacc

lst_file = None
qud_file = None
input_data = None
saw_error = False

# ====== HELPERS =======

def print_error(message, line, column=None):
    global saw_error
    saw_error = True

    msg = 'error, line %d' % line
    if column is not None:
        msg += ', column %d' % column
    msg += ': %s\n' % message
    sys.stderr.write(msg)
    lst_file.write(msg)

def find_column(lexpos):
    lastnewline = input_data.rfind('\n', 0, lexpos)
    if lastnewline < 0:
	lastnewline = 0
    return lexpos - lastnewline

# ====== LEXER =====

states = (
   ('comment','exclusive'),
)

tokens = [
   'LEFT_BRACKET',
   'RIGHT_BRACKET',
   'LEFT_CURLY_BRACKET',
   'RIGHT_CURLY_BRACKET',
   'COMMA',
   'COLON',
   'SEMICOLON',
   'EXCLAMATION_MARK',
   'ID',
   'NUM',
   'RELOP',
   'ADDOP',
   'MULOP',
   'ASSIGNOP'
]

reserved = {
    'do': 'DO',
    'for': 'FOR',
    'if': 'IF',
    'int': 'INT',
    'real': 'REAL',
    'ival': 'IVAL',
    'then': 'THEN',
    'otherwise': 'OTHERWISE',
    'print': 'PRINT',
    'procedure': 'PROCEDURE',
    'read': 'READ',
    'rval': 'RVAL',
    'variable': 'VARIABLE',
    'while': 'WHILE',
    'or': 'OROP',
    'and': 'ANDOP'
}

tokens += reserved.values()

# Regular expression rules for simple tokens
t_LEFT_BRACKET = r'\('
t_RIGHT_BRACKET = r'\)'
t_LEFT_CURLY_BRACKET = r'{'
t_RIGHT_CURLY_BRACKET = r'}'
t_COMMA = r','
t_COLON = r':'
t_SEMICOLON = r';'
t_EXCLAMATION_MARK = r'!'
t_RELOP = r'==|!=|>=|<=|<|>'
t_ADDOP = r'\+|-'
t_MULOP = r'\*|/'
t_ASSIGNOP = r':='

def t_NUM(t):
    r'\d+\.?\d+|\d+'
    if len(t.value) > 9:
        print_error('number %s exceeds constrained length of 9 digits' % t.value, t.lexer.lineno)
    return t

def t_comment(t):
    r'/\*'
    t.lexer.begin('comment')

def t_comment_end(t):
    r'\*/'
    t.lexer.begin('INITIAL')

def t_comment_skip(t):
    r'.'

def t_comment_skip_newline(t):
    r'\n'
    t.lexer.lineno += len(t.value)

def t_ID(t):
    r'[a-zA-Z]+([a-zA-Z]|\d)*'
    if len(t.value) > 9:
        print_error('id %s exceeds constrained length of 9 characters' % t.value, t.lexer.lineno)
    if t.value in reserved:
        t.type = reserved[t.value]
    return t

# define a rule so we can track line numbers
def t_newline(t):
    r'(\r?\n)+'
    t.lexer.lineno += t.value.count('\n')

# a string containing ignored characters (spaces and tabs)
t_ignore  = ' \t'
t_comment_ignore = ' \t'

# error handling for invalid tokens
def t_error(t):
    print_error("illegal character %r" % t.value[0], t.lineno)
    t.lexer.skip(1)

def t_comment_error(t):
    pass

# ======== CODE GENERATION HELPERS ========

class CodeSegment(list):
    '''convienience class that allows us to treat a list, Node and string
    equally when generating intermediate code'''
    def __init__(self, item=None):
        if item:
            if isinstance(item, Node):
                item = item.code
            super(CodeSegment, self).__init__(item)

    def add(self, *args):
        for a in args:
            if isinstance(a, list):
                self.extend(a)
            elif isinstance(a, Node):
                self.extend(a.code)
            else:
                self.append(a)
        return self # allows chaining

class Node(object):
    def __init__(self, code, addr=None, type=None, base_ip=None):
        self.code = list(code)
        self.addr = addr
        self.type = type
        self.base_ip = base_ip

    def end_offset(self):
        '''return the offset of the ip right after the end of this node's code'''
        return self.base_ip + len(self)

    def __len__(self):
        return len(self.code)

    def __bool__(self):
        return True

    def __repr__(self):
        code = ''
        if self.code:
            code = self.code[0]
            if len(self) > 1:
                code += '.. (%d more)' % (len(self) - 1)

        return '<Node type=%s len=%d addr=%s offset=%d code=%r>' % (
                    self.type if self.type else '?',
                    len(self),
                    self.addr,
                    self.base_ip,
                    code)

# temp variables generator
temp_id = 0
def new_temp():
    global temp_id
    temp_id += 1
    return 't' + str(temp_id)

# holds the instruction counter
ip = 1
def inc_ip(d):
    global ip
    ip += d

# holds the declared variables and their type
vars_dict = {}

def format_inst(type, name, *args):
    '''format an instruction in QUD:
        - type can be 'int' or 'real'
        - name is the name of an instruction without the preceding I/R
        - args are any arguments the instruction might take
    '''
    name = name.upper()
    if type == 'int':
        type = 'I'
    else:
        type = 'R'
    instpart = '%s%s' % (type, name)
    l = [instpart]
    l.extend(args)
    return ' '.join([str(s) for s in l])

# ======= PARSER ========

def p_program(p):
    '''program : PROCEDURE ID LEFT_CURLY_BRACKET declarations stmtlist RIGHT_CURLY_BRACKET'''
    if not saw_error:
        for c in p[5].code:
            qud_file.write(c)
            qud_file.write('\n')
        qud_file.write('HALT' + '\n')

def p_declarations(p):
    '''declarations : VARIABLE declarlist
                    | empty'''

def p_declarlist(p):
    '''declarlist : declarlist type COLON idents SEMICOLON'''
    for ident in p[4]:
        if ident in vars_dict:
            print_error('variable %s already declared' % ident, p.lineno(4))
        vars_dict[ident] = p[2]

def p_declarlist_error(p):
    '''declarlist : error SEMICOLON'''
    print_error('invalid variable declarations %r' % p[1].value, p.lineno(2),
                find_column(p.lexpos(2)))

def p_declarlist_single(p):
    '''declarlist : type COLON idents SEMICOLON'''
    for ident in p[3]:
        if ident in vars_dict:
            print_error('duplicate variable declaration of: %s' % ident, p.lineno(3))
        vars_dict[ident] = p[1]

def p_idents(p):
    '''idents : idents COMMA ID'''
    p[0] = p[1] + [p[3]]

def p_idents_single(p):
    '''idents : ID'''
    p[0] = [p[1]]

def p_type(p):
    '''type : INT
            | REAL'''
    p[0] = p[1]

def p_stmtlist(p):
    '''stmtlist : stmtlist stmt'''
    cs = CodeSegment().add(p[1], p[2])
    base_ip = p[1].base_ip
    p[0] = Node(cs, base_ip=base_ip)

def p_stmtlist_empty(p):
    '''stmtlist : empty'''
    p[0] = Node([], base_ip=ip)

def p_stmt(p):
    '''stmt : assignment_stmt
            | write_stmt
            | read_stmt
            | block_stmt
            | val_stmt
            | control_stmt'''
    p[0] = p[1]

def p_stmt_error(p):
    '''stmt : error SEMICOLON'''
    print_error('unexpected keyword %r' % p[1].value, p.lineno(2),
                find_column(p.lexpos(1)))
    p[0] = Node([])

def p_write_stmt(p):
    '''write_stmt : PRINT LEFT_BRACKET expression RIGHT_BRACKET SEMICOLON'''
    exp = p[3]
    cs = CodeSegment(exp).add(format_inst(exp.type, 'prt', exp.addr))
    p[0] = Node(cs, base_ip=exp.base_ip)
    inc_ip(1)

def p_write_stmt_error(p):
    '''write_stmt : PRINT LEFT_BRACKET error RIGHT_BRACKET SEMICOLON'''
    print_error('invalid expression %r' % p[3].value, p.lineno(len(p)-1),
                find_column(p.lexpos(2)))
    p[0] = Node([])

def p_read_stmt(p):
    '''read_stmt : READ LEFT_BRACKET ID RIGHT_BRACKET SEMICOLON'''
    var = p[3]
    if var in vars_dict:
        type = vars_dict[var]
        code = format_inst(type, 'inp', var)
        p[0] = Node([code], base_ip=ip)
        inc_ip(1)
    else:
        print_error('unknown variable: %s' % var, p.lineno(3))
        p[0] = Node([])

def p_assignment_stmt(p):
    '''assignment_stmt : ID ASSIGNOP expression SEMICOLON'''
    id = p[1]
    exp = p[3]
    if id in vars_dict:
        lhstype, rhstype = vars_dict[id], exp.type
        # int = real
        if lhstype == 'int' and rhstype == 'real':
            print_error('cannot implicitly convert real to int: %s (use ival)' % id, p.lineno(0))
            p[0] = Node([])
        else:
            cs = CodeSegment(exp)
            # same type
            if lhstype == rhstype:
                cs.add(format_inst(lhstype, 'asn', id, exp.addr))
            # real = int, convert int to real with itor
            elif lhstype == 'real' and rhstype == 'int':
                cs.add(format_inst('int', 'tor', id, exp.addr))

            p[0] = Node(cs, id, lhstype, base_ip=exp.base_ip)
            inc_ip(1)
    else:
        print_error('unknown variable: %s' % id, p.lineno(1))
        p[0] = Node([])

def p_control_stmt_error(p):
    '''control_stmt : IF error THEN stmt OTHERWISE stmt'''
    print_error('invalid expression %r' % p[2].value, p.lineno(1),
                find_column(p.lexpos(1)))
    p[0] = Node([])

def p_block_stmt(p):
    '''block_stmt : LEFT_CURLY_BRACKET stmtlist RIGHT_CURLY_BRACKET'''
    p[0] = p[2]

def p_ival_stmt(p):
    '''val_stmt : ID ASSIGNOP IVAL LEFT_BRACKET expression RIGHT_BRACKET SEMICOLON'''
    id = p[1]
    exp = p[5]
    if id in vars_dict:
        cs = CodeSegment(exp)
        instructions = 1
        lhstype, rhstype = vars_dict[id], exp.type
        if lhstype == 'int' and rhstype == 'int':
            cs.add(format_inst(lhstype, 'asn', id, exp.addr))
        elif lhstype == 'real' and rhstype == 'real':
            # first convert expression to an int to truncate it
            t = new_temp()
            cs.add(format_inst('real', 'toi', t, exp.addr))
            # then convert it back to a real
            cs.add(format_inst('int', 'tor', id, t))
            inc_ip(1)
        else:
            dest = 'to%s' % lhstype[0]
            cs.add(format_inst(rhstype, dest, id, exp.addr))

        p[0] = Node(cs, base_ip=exp.base_ip)
        inc_ip(1)
    else:
        print_error('unknown variable: %s' % id, p.lineno(1))
        p[0] = Node([])

def p_rval_stmt(p):
    '''val_stmt : ID ASSIGNOP RVAL LEFT_BRACKET expression RIGHT_BRACKET SEMICOLON'''
    id = p[1]
    exp = p[5]
    if id in vars_dict:
        if vars_dict[id] == 'int':
            print_error('no conversion from real to int: %s' % p[1], p.lineno(0))
            p[0] = Node([])
        else:
            cs = CodeSegment(exp).add(format_inst('int', 'tor', id, exp.addr))
            p[0] = Node(cs, base_ip=exp.base_ip)
            inc_ip(1)
    else:
        print_error('unknown variable: %s' % id, p.lineno(1))
        p[0] = Node([])

def p_jmp_placeholder(p):
    '''jmp_placeholder :'''
    # increment the ip to account for the JUMP/JMPZ instructions added when we
    # reduce
    inc_ip(1)

def p_if_control_stmt(p):
    '''control_stmt : IF LEFT_BRACKET boolexpr RIGHT_BRACKET THEN jmp_placeholder stmt OTHERWISE jmp_placeholder stmt'''
    exp = p[3]
    then_stmt = p[7]
    else_stmt = p[10]
    cs = CodeSegment(exp)
    else_jump_ip = then_stmt.end_offset()
    else_jump_ip += 1 # and add 1 for the JUMP at the end of then_stmt
    cs.add('JMPZ %d %s' % (else_jump_ip, exp.addr))
    cs.add(then_stmt)
    cs.add('JUMP %d' % else_stmt.end_offset())
    cs.add(else_stmt)

    p[0] = Node(cs, base_ip=exp.base_ip)

def p_while_control_stmt(p):
    '''control_stmt : WHILE LEFT_BRACKET boolexpr RIGHT_BRACKET DO jmp_placeholder stmt'''
    exp = p[3]
    stmt = p[7]
    cs = CodeSegment(exp)
    body_end_ip = stmt.end_offset() + 1
    body_jump_code = 'JMPZ %d %s' % (body_end_ip, exp.addr)
    cs.add(body_jump_code, stmt)
    cs.add('JUMP %d' % exp.base_ip)
    inc_ip(1)

    p[0] = Node(cs, base_ip=exp.base_ip)

def p_step_fixer(p):
    '''step_fixer : empty'''
    # the STMT in a for loop is generated after the STEP, but when we're
    # writing the code, it is executed before -- account for the 2 instructions
    # in STEP right before generating STMT
    inc_ip(-2)

def p_for_control_stmt(p):
    '''control_stmt : FOR LEFT_BRACKET assignment_stmt boolexpr SEMICOLON jmp_placeholder step RIGHT_BRACKET step_fixer stmt'''
    assign_stmt = p[3]
    bool_exp = p[4]
    step = p[7]
    stmt = p[10]

    # rearranging code; see comment in p_step_fixer
    step.base_ip = stmt.end_offset()

    cs = CodeSegment(assign_stmt)
    cs.add(bool_exp)
    end_jump = step.end_offset() + 1 # for the JUMP
    cs.add('JMPZ %d %s' % (end_jump, bool_exp.addr))
    cs.add(stmt)
    cs.add(step)
    cs.add('JUMP %d' % bool_exp.base_ip)
    inc_ip(1)
    p[0] = Node(cs, base_ip=assign_stmt.base_ip)

def step_helper(op, l_id, r_id, num):
    op_to_inst = {
        '+' : 'add',
        '-' : 'sub',
        '*' : 'mlt',
        '/' : 'div'
    }

    if l_id in vars_dict:
        l_id_type = vars_dict[l_id]
        if r_id in vars_dict:
            r_id_type = vars_dict[r_id]
        else:
            print_error('unknown variable: %s' % l_id, p.lineno(1))
            return Node([])
        num_type = 'real' if '.' in num else 'int'
        r_type = 'int' if num_type == 'int' and r_id_type == 'int' else 'real'
        if l_id_type == 'int' and r_type == 'real':
            print_error('no conversion from real to int: %s' % r_id, p.lineno(0))
        t = new_temp()
        cs = CodeSegment()
        cs.add(format_inst(l_id_type, op_to_inst[op], t, r_id, num))
        cs.add(format_inst(l_id_type, 'asn', l_id, t))
        inc_ip(2)
        return Node(cs, base_ip=ip)
    else:
        print_error('unknown variable: %s' % l_id, p.lineno(1))
        return Node([])

def p_step_add(p):
    '''step : ID ASSIGNOP ID ADDOP NUM'''
    node = step_helper(p[4], p[1], p[3], p[5])
    p[0] = node

def p_step_mul(p):
    '''step : ID ASSIGNOP ID MULOP NUM'''
    node = step_helper(p[4], p[1], p[3], p[5])
    p[0] = node

def p_boolexpr(p):
    '''boolexpr : boolexpr OROP boolterm'''
    t1 = new_temp()
    t2 = new_temp()
    l = p[1]
    r = p[3]
    cs = CodeSegment().add(l, r)
    cs.add(format_inst('int', 'add', t1, l.addr, r.addr))
    cs.add(format_inst('int', 'grt', t2, t1, 0))
    p[0] = Node(cs, t2, base_ip=l.base_ip)
    inc_ip(2)

def p_boolexpr_boolterm(p):
    '''boolexpr : boolterm'''
    p[0] = p[1]

def p_boolterm(p):
    '''boolterm : boolterm ANDOP boolfactor'''
    t = new_temp()
    l = p[1]
    r = p[3]
    cs = CodeSegment().add(l, r)
    cs.add(format_inst('int', 'mlt', t, l.addr, r.addr))
    p[0] = Node(cs, t, base_ip=l.base_ip)
    inc_ip(1)

def p_boolterm_boolfactor(p):
    '''boolterm : boolfactor'''
    p[0] = p[1]

def p_boolfactor(p):
    '''boolfactor : expression RELOP expression'''
    l, sign, r = p[1:]
    cs = CodeSegment().add(l, r)
    cslen = len(cs)
    conv = {'==': 'EQL',
            '!=': 'NQL',
            '<': 'LSS',
            '>': 'GRT',
            '<=': 'LSS',
            '>=': 'GRT'}

    lhstype, rhstype = l.type, r.type
    lhsaddr = l.addr
    rhsaddr = r.addr
    if lhstype != rhstype:
        # convert the int side to a real
        conversion_t = new_temp()
        if lhstype == 'int':
            cs.add(format_inst('int', 'tor', conversion_t, l.addr))
            lhsaddr = conversion_t
            lhstype = 'real'
        else:
            cs.add(format_inst('int', 'tor', conversion_t, r.addr))
            rhsaddr = conversion_t

    result = new_temp()
    cs.add(format_inst(lhstype, conv[sign], result, lhsaddr, rhsaddr))
    if sign in ('<=', '>='):
        t2 = new_temp()
        t3 = new_temp()
        cs.add(format_inst(lhstype, 'eql', t2, lhsaddr, rhsaddr))
        cs.add(format_inst('int', 'add', t3, result, t2))
        cs.add(format_inst('int', 'grt', result, t3, 0))
    p[0] = Node(cs, result, base_ip=l.base_ip)
    inc_ip(len(cs) - cslen)

def p_boolfactor_not(p):
    '''boolfactor : EXCLAMATION_MARK LEFT_BRACKET boolfactor RIGHT_BRACKET'''
    t = new_temp()
    exp = p[3]
    cs = CodeSegment(exp)
    cs.add(format_inst('int', 'nql', t, exp.addr, 1))
    p[0] = Node(cs, t, base_ip=exp.base_ip)
    inc_ip(1)

def p_expression(p):
    '''expression : expression ADDOP term'''
    p[0] = arithmetic_helper(*p[1:])

def p_expression_term(p):
    '''expression : term'''
    p[0] = p[1]

def p_term(p):
    '''term : term MULOP factor'''
    p[0] = arithmetic_helper(*p[1:])

def arithmetic_helper(l, sign, r):
    '''generate code to compute the expression 'l <sign> r'

    when the types are not equal, we convert the int side to
    real before the code to do the arithmetic'''
    lhsaddr, rhsaddr = l.addr, r.addr
    type_ = l.type
    cs = CodeSegment().add(l, r)

    if l.type != r.type:
        # convert the int side to real
        type_ = 'real'
        conversion_t = new_temp()
        if l.type == 'int':
            cs.add(format_inst('int', 'tor', conversion_t, l.addr))
            lhsaddr = conversion_t
        else:
            cs.add(format_inst('int', 'tor', conversion_t, r.addr))
            rhsaddr = conversion_t
        inc_ip(1)

    if sign == '+':
        op = 'add'
    elif sign == '-':
        op = 'sub'
    elif sign == '*':
        op = 'mlt'
    else:
        op = 'div'

    result = new_temp()
    cs.add(format_inst(type_, op, result, lhsaddr, rhsaddr))
    inc_ip(1)
    return Node(cs, result, type_, base_ip=l.base_ip)

def p_term_factor(p):
    '''term : factor'''
    p[0] = p[1]

def p_factor_expr(p):
    '''factor : LEFT_BRACKET expression RIGHT_BRACKET'''
    p[0] = p[2]

def p_factor_id(p):
    '''factor : ID'''
    if p[1] in vars_dict:
        p[0] = Node([], p[1], vars_dict[p[1]], base_ip=ip)
    else:
        print_error('unknown variable: %s' % p[1], p.lineno(1))
        p[0] = Node([])

def p_factor_num(p):
    '''factor : NUM'''
    type = 'real' if '.' in p[1] else 'int'
    p[0] = Node([], p[1], type, base_ip=ip)

def p_factor_error(p):
    '''factor : LEFT_BRACKET error RIGHT_BRACKET'''
    print_error('invalid expression %r' % p[2].value, p.lineno(3),
                find_column(p.lexpos(1)))
    p[0] = Node([])

def p_empty(p):
    'empty :'
    pass

# error rule for syntax errors
def p_error(p):
    pass

#------------------------------main-----------------------------------------------

if __name__ == "__main__":
    # build the lexer & parser
    lex.lex()
    parser = yacc.yacc()

    if len(sys.argv) < 2:
        print 'no input file'
        sys.exit(1)

    path = sys.argv[1]
    if path == '-':
        print 'reading input from stdin and writing to stdin.{qud,lst}'
        basename = path = 'stdin'
        input_file = sys.stdin
    else:
        basename = os.path.basename(path)
        if os.path.splitext(basename)[1].lower() != '.cpl':
            print 'can only parse .cpl files'
            sys.exit(1)
        basename = basename[:-4]
        input_file = open(path)

    lst_file = open(os.path.join(os.path.dirname(path), basename) + '.lst', 'w')
    qud_filename = os.path.join(os.path.dirname(path), basename) + '.qud'
    qud_file = open(qud_filename, 'w')

    input_data = input_file.read()

    for i, line in enumerate(input_data.splitlines()):
        lst_file.write('%.2d: %s\n' % (i + 1, line))
    lst_file.write('\n')

    try:
        parser.parse(input_data, tracking=True)
    finally:
        lst_file.close()
        qud_file.close()
        if saw_error:
            sys.stderr.write('no code was generated')
            os.remove(qud_filename)
