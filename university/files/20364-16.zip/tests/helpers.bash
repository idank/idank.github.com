cpq() {
    $TESTDIR/../cpq.py "$@" 2>&1 | grep -v LALR
    test ${PIPESTATUS[0]} -eq 0
}

qx() { $TESTDIR/../qx.py "$@"; }

function compile() {
    echo "procedure main {" > script.cpl
    sed 's/^/    /g' >> script.cpl
    echo "}" >> script.cpl
    cpq script.cpl
}
