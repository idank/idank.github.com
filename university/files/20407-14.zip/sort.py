import random

def bubblesort(a):
    cmps = copies = 0

    for j in range(len(a)-1, -1, -1):
        for i in range(j):
            cmps += 1
            if a[i] > a[i+1]:
                copies += 3
                a[i], a[i+1] = a[i+1], a[i]

    return cmps, copies

def bidibubblesort(a):
    cmps = copies = 0

    left = -1
    right = len(a)

    while left < right:
        flipped = False
        left += 1
        right -= 1

        for i in range(left, right):
            cmps += 1
            if a[i] > a[i+1]:
                copies += 3
                a[i], a[i+1] = a[i+1], a[i]
                flipped = True

        if not flipped:
            break
        else:
            flipped = False

        for i in range(right-1, left-1, -1):
            cmps += 1
            if a[i] > a[i+1]:
                copies += 3
                a[i], a[i+1] = a[i+1], a[i]
                flipped = True

        if not flipped:
            break

    return cmps, copies

def shakesort(a):
    cmps = copies = 0

    left = 0
    right = len(a)-1

    while left < right:
        min = max = left

        for i in range(left+1, right+1):
            cmps += 2
            if a[min] > a[i]:
                min = i
            if a[max] < a[i]:
                max = i

        copies += 3
        a[min], a[left] = a[left], a[min]

        if max == left:
            copies += 3
            a[min], a[right] = a[right], a[min]
        else:
            copies += 3
            a[max], a[right] = a[right], a[max]

        left += 1
        right -= 1

    return cmps, copies

def main():
    stats = [[f, 0, 0] for f in (bubblesort, bidibubblesort, shakesort)]

    for i in range(100):
        a = [random.randint(1, 101) for x in range(200)]

        for s in stats:
            aa = list(a)
            cmps, copies = s[0](aa)
            assert aa == sorted(a)
            s[1] += cmps
            s[2] += copies

    for func, cmps, copies in stats:
        cmps /= 100.0
        copies /= 100.0
        print "%s did %d comparsions, %d copies on average" % (func.__name__, cmps, copies)

if __name__ == "__main__":
    main()
