#!/usr/bin/python

import sys
import tree, linkedlist

class member(object):
    """A member in the library. Has an id, a name and a list of books"""
    def __init__(self, id_, name):
        self._id = id_
        self._name = name
        self._books = linkedlist.linkedlist()

    id_ = property(fget=lambda self: self._id)
    name = property(fget=lambda self: self._name)
    books = property(fget=lambda self: self._books)

    def __cmp__(self, other):
        # delegate comparisons to the id field
        if isinstance(other, int):
            return cmp(self._id, other)
        return cmp(self._id, other._id)

    def __repr__(self):
        return repr(self._id) + ':' + self.name

class book(object):
    """A book in the library. Has a code and a reference to the member who borrowed it"""
    def __init__(self, code, member):
        self._code = code
        self._member = member

    code = property(fget=lambda self: self._code)
    member = property(fget=lambda self: self._member)

    def __cmp__(self, other):
        # delegate comparisons to the code field
        if isinstance(other, str):
            return cmp(self._code, other)
        return cmp(self._code, other._code)

    def __str__(self):
        return self._code

class library(object):
    def __init__(self):
        self.members = tree.rbtree()
        self.books = tree.rbtree()

    def add_member(self, id_, name):
        """Adds a member to the library"""
        if self.members.find(id_):
            raise ValueError('member id %d already exists!' % id_)
        m = member(id_, name)
        self.members.insert(m)
        return m

    def remove_member(self, id_, name):
        """Removes a member from the library"""
        try:
            return self.members.delete(id_)
        except ValueError:
            raise ValueError('member id %d not found' % id_)

    def borrow_book(self, id_, name, code):
        """Borrow a book from the library"""
        m = self.members.find(id_)
        if not m:
            raise ValueError('member id %d not found' % id_)
        elif len(m.books) == 10:
            raise ValueError('a member cannot borrow more than 10 books')
        elif self.books.find(code):
            raise ValueError('book %s is already borrowed to someone' % code)
        else:
            m.books.insert(code)
            b = book(code, m)
            self.books.insert(b)
            return b

    def return_book(self, id_, name, code):
        """Return a book to the library"""
        m = self.members.find(id_)
        if not m:
            raise ValueError('member id %d not found' % id_)
        elif not m.books.find(code):
            raise ValueError('member %d didn''t borrow book %s' % (id_, code))
        else:
            m.books.remove(code)
            return self.books.delete(code)

    def member_books(self, id_):
        """Return a list of the books of a member"""
        m = self.members.find(id_)
        if not m:
            raise ValueError('member id %d not found' % id_)
        else:
            return m.books

    def find_member_by_book(self, code):
        """Return the member who borrowed a book"""
        b = self.books.find(code)
        if not b:
            raise ValueError('book %s not found' % code)
        else:
            return b.member

    def most_borrowed_members(self):
        """Return a list of members who borrowed the most books"""

        # traverse the tree and find the max book count
        maxbookcount = 0
        for x in self.members.walk():
            if len(x.books) > maxbookcount:
                maxbookcount = len(x.books)

        if maxbookcount > 0:
            for x in self.members.walk():
                if len(x.books) == maxbookcount:
                    yield x

def main():
    if len(sys.argv) == 1:
        print 'usage: %s -|FILE' % sys.argv[0]
        return
    elif sys.argv[1] == '-':
        f = sys.stdin
    else:
        f = open(sys.argv[1])

    lib = library()
    while True:
        l = f.readline()
        if not l:
            break
        tokens = l.rstrip().split()

        # new member
        if tokens[0] == '+':
            m = lib.add_member(int(tokens[2]), tokens[1])
            print 'added member', m
        # remove member
        elif tokens[0] == '-':
            m = lib.remove_member(int(tokens[2]), tokens[1])
            print 'removed member', m
        # return/borrow a book
        elif len(tokens) == 4:
            name, id_, code = tokens[0], int(tokens[1]), tokens[2]

            if tokens[-1] == '+':
                b = lib.borrow_book(id_, name, code)
                print 'member', b.member, 'borrowed book', b
            else:
                b = lib.return_book(id_, name, code)
                print 'member', b.member, 'returned book', b
        # queries
        elif tokens[0] == '?':
            if tokens[1] == '!':
                most_borrowed = list(lib.most_borrowed_members())
                print 'members with currently most borrowed books:', most_borrowed
            # which books member X has
            elif len(tokens[1]) == 9:
                books = list(lib.member_books(int(tokens[1])))
                print 'what books member %s borrowed? %s' % (tokens[1], str(books))
            # which member has book X
            else:
                m = lib.find_member_by_book(tokens[1])
                print 'who borrowed book', tokens[1], '? member', m
        else:
            print 'error: unknown query'
    if f != sys.stdin:
        f.close()

if __name__ == '__main__':
    main()
