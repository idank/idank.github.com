class node(object):
    """A node with prev and next pointers."""
    def __init__(self, key):
        self._key = key
        self.prev = None
        self.next = None

    key = property(fget=lambda self: self._key)

    def __str__(self):
        return str(self.key)

    def __repr__(self):
        return repr(self.key)

class linkedlist(object):
    """A bidirectional linked list"""
    def __init__(self):
        self.head = None
        self.size = 0

    def insert(self, key):
        n = node(key)
        n.next = self.head
        if self.head:
            self.head.prev = n
        self.head = n
        self.size += 1

    def __len__(self):
        return self.size

    def find(self, key):
        x = self.head
        while x and x.key != key:
            x = x.next
        return x

    def remove(self, key):
        x = self.find(key)
        if x is None:
            raise ValueError('%r not found' % key)
        else:
            p = x.prev
            n = x.next
            if p:
                p.next = n
            else:
                self.head = n
            if n:
                n.prev = p
            self.size -= 1

    def __iter__(self):
        x = self.head
        while x:
            yield x
            x = x.next
