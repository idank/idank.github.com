#include <stdio.h>
#include <stdlib.h>

unsigned int my_rotate(unsigned int a, int b) {
  unsigned int rotated_bits = 0;

  if (b == 0)
    return a;
  else if (b > 0) {
    rotated_bits = a << (sizeof(a) * 8 - b);
    a >>= b;
  }
  else {
    b = -b;
    rotated_bits = a >> (sizeof(a) * 8 - b);
    a <<= b;
  }

  a |= rotated_bits;

  return a;
}

// print x in binary notation
void printf_binary(unsigned int x) {
  char b[sizeof(x) * 8 + 1] = {0};

  printf("0b");
  for (int i = 0; i < sizeof(x) * 8; i++) {
    if (x & (1 << i)) {
      b[sizeof(x) * 8 - i - 1] = '1';
    }
    else {
      b[sizeof(x) * 8 - i - 1] = '0';
    }
  }
  printf("%s", b);
}

int main(int argc, const char* argv[]) {
  if (argc != 3) {
    printf("need exactly 2 arguments: <uint to rotate> <rotate count>\n");
    return 1;
  }

  unsigned int a = (unsigned int)atoi(argv[1]);
  int b = atoi(argv[2]);
  unsigned int aftera = my_rotate(a, b);

  printf("before: ");
  printf_binary(a);
  printf("\n");

  printf("after:  ");
  printf_binary(aftera);
  printf("\n");

  return 0;
}
