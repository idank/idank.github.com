#include <stdio.h>

typedef enum sequence_order {
  undetermined,
  decreasing,
  strictly_decreasing,
  increasing,
  strictly_increasing,
} sequence_order;

const char* stringified_sequence_order[5] = {
  "undetermined",
  "decreasing",
  "strictly decreasing",
  "increasing",
  "strictly increasing"
};

int getputc() {
  int c = fgetc(stdin);
  if (c != EOF)
    putchar(c);

  return c;
}

int main(int argc, const char* argv[]) {
  int prev, curr;
  sequence_order order;

  prev = getputc();
  curr = getputc();

  // arbitrarily define a sequence with < 2 elements as increasing
  if (prev == EOF || curr == EOF) {
    printf("\n\nsequence order: increasing\n");
    return 0;
  }

  // we've seen at least 2 elements at this point,
  // determine initial order
  if (prev == curr) {
    order = increasing;
  }
  else if (prev < curr) {
    order = strictly_increasing;
  }
  else {
    order = strictly_decreasing;
  }

  prev = curr;

  while ((curr = getputc()) != EOF) {
    switch (order) {
      case undetermined:
        break;
      case increasing:
        if (curr < prev)
          order = undetermined;
        break;
      case strictly_increasing:
        if (curr == prev)
          order = increasing;
        else if (curr < prev)
          order = undetermined;
        break;
      case decreasing:
        if (curr > prev)
          order = undetermined;
        break;
      case strictly_decreasing:
        if (curr == prev)
          order = decreasing;
        else if (curr > prev)
          order = undetermined;
        break;
    }

    prev = curr;
  }

  if (ferror(stdin)) {
    fprintf(stderr, "error reading from stdin\n");
    return 1;
  }
  else {
    printf("\n\nsequence order: %s\n", stringified_sequence_order[order]);
  }

  return 0;
}
