#include <stdlib.h>
#include <stdio.h>
#include <string.h>

/*
  we use a simple dynamic array for our set

  we maintain a length and capacity counts to know the current
  item count and how much room we have in total

  we double the set size whenever it is full, this
  gives us O(1) amortized insertion (without the check
  for existance). since a set doesn't allow duplicates,
  we check for membership on insertion. in total our
  insertion is thus O(n).
*/
typedef struct intset {
    int* items;
    size_t length;   // current item count in the set
    size_t capacity; // size of items array
} intset;

intset intset_create() {
  intset is;
  is.items = malloc(sizeof(int));
  is.length = 0;
  is.capacity = 1;

  return is;
}

void intset_destroy(intset is) {
  free(is.items);
}

void intset_grow(intset* is) {
  is->capacity *= 2;
  is->items = realloc(is->items, is->capacity * sizeof(int));
}

int intset_in(intset* is, int item) {
  for (int i = 0; i < is->length; i++) {
    if (is->items[i] == item)
      return 1;
  }

  return 0;
}

void intset_add(intset* is, int item) {
  if (intset_in(is, item))
    return;

  if (is->length == is->capacity)
    intset_grow(is);

  is->items[is->length++] = item;
}

#define LINEBUF_SIZE 100

int main(int argc, const char* argv[]) {
  char linebuffer[LINEBUF_SIZE];
  intset is = intset_create();

  while (1) {
    // check for end of input
    if (fgets(linebuffer, LINEBUF_SIZE, stdin) == NULL)
      break;

    // split line on space
    char* token = strtok(linebuffer, " ");
    while (token != NULL) {
        // add read int to the set
        intset_add(&is, atoi(token));

        token = strtok(NULL, " ");
    }
  }

  for (int i = 0; i < is.length; i++) {
    if (i == is.length - 1)
      printf("%d", is.items[i]);
    else
      printf("%d ", is.items[i]);
  }

  printf("\n");

  intset_destroy(is);

  return 0;
}
