#!/usr/bin/env python

# requires bitstring package, install with 'sudo pip install bitstring'

__author__ = 'Idan Kamara'

import sys
import bitstring

if __name__ == '__main__':
    f = open(sys.argv[1])

    opcode_to_inst = {
            0: 'mov',
            1: 'cmp',
            2: 'add',
            3: 'sub',
            4: 'lea',
            5: 'not',
            6: 'clr',
            7: 'inc',
            8: 'dec',
            9: 'jmp',
            10: 'bne',
            11: 'red',
            12: 'prn',
            13: 'jsr',
            14: 'rts',
            15: 'stop'
        }

    inst_operands_count = {
            'mov': 2,
            'cmp': 2,
            'add': 2,
            'sub': 2,
            'lea': 2,
            'not': 1,
            'clr': 1,
            'inc': 1,
            'dec': 1,
            'jmp': 1,
            'bne': 1,
            'red': 1,
            'prn': 1,
            'jsr': 1,
            'rts': 0,
            'stop': 0
        }

    addr_string = {
            0: 'immediate',
            1: 'direct',
            2: 'dist',
            3: 'iregister'
        }

    group_string = {
            0: '0 args',
            1: '1 args',
            2: '2 args'
        }

    ic = 100
    argcount = 0

    header = f.readline()
    codelen, datalen = header.strip().split(' ')
    codelen = int(codelen, 16)
    datalen = int(datalen, 16)

    def readinst():
        line = f.readline()
        if not line:
            raise EOFError
        addr, insts = line.strip().split(' ')
        return int(addr, 16), bitstring.ConstBitStream(hex=insts)

    print 'reading %d instructions' % codelen

    while ic - 100 < codelen:
        addr, s = readinst()

        inst = s.read(12)

        group = inst.read(2)
        opcode = inst.read(4)
        srcaddr = inst.read(2)
        dstaddr = inst.read(2)
        ERA = inst.read(2)

        sERA = 'AER'[ERA.uint]
        sdstaddr = addr_string[dstaddr.uint]
        ssrcaddr = addr_string[srcaddr.uint]
        sopcode = opcode_to_inst[opcode.uint]
        sgroup = group_string[group.uint]

        parts = [group.bin, opcode.bin, srcaddr.bin, dstaddr.bin, ERA.bin]

        if argcount:
            print

        argcount = inst_operands_count[sopcode]
        if group.uint != argcount:
            raise Exception('bad group for %r, expected %d, got %d' % (
                sopcode, argcount, group.uint))

        if argcount < 2:
            ssrcaddr = '----'

        if argcount < 1:
            sdstaddr = '----'

        if argcount == 2 and (sdstaddr == 'iregister' and ssrcaddr == 'iregister'):
            argcount -= 1

        if argcount == 0:
            nextread = 'reading next instruction'
        elif argcount == 1:
            nextread = 'reading an operand'
        elif argcount == 2:
            nextread = 'reading two operands'

        parts.append('(%s)' % nextread)

        print ('({0:03d}) <{1:03} {1:#03x}>:   '
              '{2:^7} {3:^8} {4:^10} {5:^10} {6:>6}    {7}').format(
                      ic - 100, addr, *parts)

        print '{0}{1:^7} {2:^9} {3:^10} {4:^10} {5:>4}'.format(
                ' '*20, sgroup, sopcode, ssrcaddr, sdstaddr, sERA)

        print

        ic += 1

        for i in range(argcount):
            addr, operand = readinst()
            remainder = operand.read(10)
            ERA = operand.read(2)
            if ERA.uint > 2:
                sERA = 'bad ARE value'
            else:
                sERA = 'AER'[ERA.uint]

            if sdstaddr == 'iregister' and ssrcaddr == 'iregister':
                srcreg = remainder.read(5)
                dstreg = remainder.read(5)
                soperand = '{0:^10} {1:^10} {2}'.format(srcreg.bin,
                        dstreg.bin, ERA.bin)

                if srcreg.uint > 7:
                    ssrcreg = 'bad register'
                else:
                    ssrcreg = 'r%d' % srcreg.uint

                if dstreg.uint > 7:
                    sdstreg = 'bad register'
                else:
                    sdstreg = 'r%d' % dstreg.uint

                print ('({0:03d}) <{1:03} {1:#03x}>:   {2}').format(
                        ic - 100, addr, soperand)

                print '{0}{1:^10} {2:^10} {3}'.format(
                        ' '*20, ssrcreg, sdstreg, sERA)
            elif sdstaddr == 'iregister' and (i == 1 or argcount == 1):
                srcreg = remainder.read(5)
                dstreg = remainder.read(5)
                soperand = '{0:^10} {1:^10} {2}'.format(srcreg.bin,
                        dstreg.bin, ERA.bin)

                ssrcreg = '----'

                if dstreg.uint > 7:
                    sdstreg = 'bad register'
                else:
                    sdstreg = 'r%d' % dstreg.uint

                print ('({0:03d}) <{1:03} {1:#03x}>:   {2}').format(
                        ic - 100, addr, soperand)

                print '{0}{1:^10} {2:^10} {3}'.format(
                        ' '*20, ssrcreg, sdstreg, sERA)
            elif ssrcaddr == 'iregister' and i == 0:
                srcreg = remainder.read(5)
                dstreg = remainder.read(5)
                soperand = '{0:^10} {1:^10} {2}'.format(srcreg.bin,
                        dstreg.bin, ERA.bin)

                sdstreg = '----'

                if srcreg.uint > 7:
                    ssrcreg = 'bad register'
                else:
                    ssrcreg = 'r%d' % srcreg.uint

                print ('({0:03d}) <{1:03} {1:#03x}>:   {2}').format(
                        ic - 100, addr, soperand)

                print '{0}{1:^10} {2:^10} {3}'.format(
                        ' '*20, ssrcreg, sdstreg, sERA)
            else:
                soperand = '%s %s' % (remainder.bin, ERA.bin)

                print ('({0:03d}) <{1:03} {1:#03x}>:     '
                       '{2}    {3}').format(ic - 100, addr, soperand, sERA)

            ic += 1

    dc = ic

    print 'reading %d data' % datalen
    for _ in range(datalen):
        addr, s = readinst()
        i = s.int
        if i == 0:
            c = '\\0'
        else:
            try:
                c = repr(chr(i))
            except ValueError:
                c = '-'

        print ('({0:03d}) {1:#012b} <{1:03} {1:#03x}>:   {2:<7} {3}').format(
                      dc - 100, addr, s.int, c)

        dc += 1
