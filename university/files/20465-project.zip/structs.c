#include <assert.h>
#include <stdlib.h>

#include "structs.h"

int_array* make_int_array() {
    int_array* il = (int_array*)malloc(sizeof(int_array));
    il->list = (int*)malloc(sizeof(int));
    il->length = 0;
    il->capacity = 1;

    return il;
}

void append_int_array(int_array* il, int value) {
    int* v = appendempty_int_array(il);
    *v = value;
}

int* appendempty_int_array(int_array* il) {
    if (il->length == il->capacity) {
        il->capacity *= 2;
        il->list = (int*)realloc(il->list, il->capacity * sizeof(int));
    }

    int* v = &il->list[il->length];
    *v = 0;
    il->length += 1;

    return v;
}

void destroy_int_array(int_array** il) {
    if ((*il)->list) {
        free((*il)->list);
        (*il)->list = NULL;
    }

    free(*il);
    *il = NULL;
}

int_array* code = NULL;
int_array* data = NULL;

int ic() {
    assert(code != NULL);

    return code->length;
}

int dc() {
    assert(data != NULL);

    return data->length;
}
