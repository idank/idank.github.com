#ifndef STRUCTS_H
#define STRUCTS_H

#include "sds.h"

/* simple implemetation of a dynamic int array */
typedef struct int_array {
    int* list;
    size_t length;
    size_t capacity;
} int_array;

/* allocate an int array with room for 1 element */
int_array* make_int_array();

/* append the given int to the end of the array,
   doubling its size if necessary */
void append_int_array(int_array* il, int value);

/* same as above, but return a pointer to the newly
   added element */
int* appendempty_int_array(int_array* il);

/* free the given array */
void destroy_int_array(int_array** il);

#define NUM_ADDRESSING 4

/* possible addressing modes for an operand */
typedef enum operand_addressing {
  immediate,
  direct,
  dist,
  iregister
} operand_addressing;

/* an operand of an instruction */
typedef struct inst_operand {
  /* the addressing */
  operand_addressing kind;

  union value {
    /* if this is a register or an immediate, i will contain its
       number */
    int i;

    /* the possible labels if this is dist or direct */
    sds label[2];
  } value;
} inst_operand;

/* the code and data arrays */
extern int_array* code;
extern int_array* data;

/* conveinence functions to return the length
   of the code and data arrays */
int ic();
int dc();

#endif
