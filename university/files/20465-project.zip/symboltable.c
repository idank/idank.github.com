#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "sds.h"
#include "structs.h"
#include "symboltable.h"

symbol_table_entry* symboltbl = NULL;

extern int saw_error;

void destroy_symbol_table() {
  symbol_table_entry* ste = symboltbl;

  while (ste != NULL) {
    symbol_table_entry* next = ste->next;

    sdsfree(ste->label);
    replace_entry* pre = ste->replace_list;
    while (pre != NULL) {
      replace_entry* prenext = pre->next;
      sdsfree(pre->labels[0]);
      sdsfree(pre->labels[1]);
      free(pre);

      pre = prenext;
    }

    free(ste);
    ste = next;
  }

  symboltbl = NULL;
}

symbol_table_entry* find_symbol_table_entry(sds label) {
  symbol_table_entry* p = symboltbl;

  while (p != NULL) {
    if (strcmp(p->label, label) == 0) {
      return p;
    }

    p = p->next;
  }

  return NULL;
}

symbol_table_entry* make_symbol_table_entry() {
  symbol_table_entry* entry = (symbol_table_entry*)malloc(sizeof(symbol_table_entry));
  entry->label = NULL;
  entry->code_offset = 0;
  entry->ic = 0;
  entry->replace_list = NULL;
  entry->next = NULL;
  entry->isentry = 0;

  if (symboltbl == NULL) {
    symboltbl = entry;
  }
  else {
    symbol_table_entry* p = symboltbl;

    // add the new entry to the tail
    while (p != NULL) {
      if (p->next == NULL) {
        p->next = entry;
        break;
      }

      p = p->next;
    }
  }

  return entry;
}

void append_replace_entry(int code_offset, int instruction_offset, sds l1, sds l2) {
  symbol_table_entry* ste = find_symbol_table_entry(l1);
  if (ste == NULL) {
    ste = make_symbol_table_entry();
    ste->label = sdsdup(l1);
    ste->type = entry_unknown;
  }

  replace_entry* entry = (replace_entry*)malloc(sizeof(replace_entry));
  entry->next = NULL;
  entry->code_offset = code_offset;
  entry->instruction_offset = instruction_offset;
  entry->labels[0] = sdsdup(l1);
  entry->labels[1] = NULL;

  if (l2)
    entry->labels[1] = sdsdup(l2);

  if (ste->replace_list == NULL)
    // it's the first entry
    ste->replace_list = entry;
  else {
    replace_entry* p = ste->replace_list;

    // add the entry to the end of the replace list
    while (p != NULL) {
      if (p->next == NULL) {
        p->next = entry;
        break;
      }

      p = p->next;
    }
  }
}

void error_missing_label(sds label) {
    sds s = sdscatprintf(sdsempty(),
                         "label '%s' not declared in file",
                         label);
    printf("error: %s\n", s);
    saw_error++;
    sdsfree(s);
}

void error_external_label(sds label) {
    sds s = sdscatprintf(sdsempty(),
                         "external label '%s' cannot be used "
                         "in ~(a, b) dist addressing",
                         label);
    printf("error: %s\n", s);
    saw_error++;
    sdsfree(s);
}

int adjusted_ste_offset(symbol_table_entry* entry) {
    int offset = entry->code_offset;
    if (entry->type == entry_code)
      offset += 100;
    else if (entry->type == entry_data) {
      offset += 100 + ic();
    }

    return offset;
}

int resolve_replacements() {
    symbol_table_entry* ste = symboltbl;

    while (ste != NULL) {
      if (ste->type == entry_unknown) {
        error_missing_label(ste->label);
        ste = ste->next;

        continue;
      }

      replace_entry* pre = ste->replace_list;
      while (pre != NULL) {
        assert(sdslen(pre->labels[0]));

        /* ~(a, b) */
        if (pre->labels[1]) {
          symbol_table_entry* ste1 = find_symbol_table_entry(pre->labels[0]);
          symbol_table_entry* ste2 = find_symbol_table_entry(pre->labels[1]);
          int resolve = 1;

          if (!ste1 || ste1->type == entry_unknown) {
            error_missing_label(pre->labels[0]);
            resolve = 0;
          }
          else if (ste1->type == entry_external) {
            error_external_label(pre->labels[0]);
            resolve = 0;
          }

          if (!ste2 || ste2->type == entry_unknown) {
            error_missing_label(pre->labels[1]);
            resolve = 0;
          }
          else if (ste2->type == entry_external) {
            error_external_label(pre->labels[1]);
            resolve = 0;
          }

          if (resolve) {
            int ste1adjustedoffset = adjusted_ste_offset(ste1);
            int ste2adjustedoffset = adjusted_ste_offset(ste2);

            int maxdist = abs(ste1adjustedoffset - ste2adjustedoffset);
            int instoffset = pre->instruction_offset + 100;

            if (abs(instoffset - ste1adjustedoffset) > maxdist)
              maxdist = abs(instoffset - ste1adjustedoffset);
            if (abs(instoffset - ste2adjustedoffset) > maxdist)
              maxdist = abs(instoffset - ste2adjustedoffset);

            code->list[pre->code_offset] = maxdist << 2;
          }
        }
        else {
          symbol_table_entry* ste = find_symbol_table_entry(pre->labels[0]);
          if (!ste || ste->type == entry_unknown)
            error_missing_label(pre->labels[0]);
          else {
            int adjustedoffset = adjusted_ste_offset(ste);

            code->list[pre->code_offset] = adjustedoffset << 2;

            // set ARE bits to external
            if (ste->type == entry_external)
              code->list[pre->code_offset] |= 1;
            else if (ste->type == entry_code || ste->type == entry_data)
              code->list[pre->code_offset] |= 2;
          }
        }

        pre = pre->next;
      }

      ste = ste->next;
    }

    return 1;
}

int write_external_entry_files(sds extfile, sds entfile) {
  FILE* extfp = fopen(extfile, "wb");
  FILE* entfp = fopen(entfile, "wb");

  if (!extfp || !entfp) {
    sds s = sdscatprintf(sdsempty(),
                         "error opening %s or %s",
                         extfile,
                         entfile);
    perror(s);
    sdsfree(s);

    return 1;
  }

  symbol_table_entry* ste = symboltbl;

  while (ste != NULL) {
    if (ste->type == entry_external) {
        replace_entry* pre = ste->replace_list;

        while (pre != NULL) {
            fprintf(extfp, "%s %X\n", ste->label, pre->code_offset + 100);

            pre = pre->next;
        }
    }
    else if (ste->isentry) {
      int adjustedoffset = adjusted_ste_offset(ste);
      fprintf(entfp, "%s %X\n", ste->label, adjustedoffset);
    }

    ste = ste->next;
  }

  fclose(extfp);
  fclose(entfp);

  return 0;
}
