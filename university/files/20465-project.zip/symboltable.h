#ifndef SYMBOLTABLE_H
#define SYMBOLTABLE_H

/* a linked list of places in the code array where
   references to labels have occurred and will need to
   be updated when the symbol table entry is resolved */
typedef struct replace_entry {
    struct replace_entry* next;

    /* the offset of this entry in the code array */
    int code_offset;

    /* the offset where the instruction that caused this replacement to be
       created, e.g.:

       mov x, r1

       will have offset = 1 but instruction_offset will be 0. this is used
       to calculate ~(a, b) distances */
    int instruction_offset;
    sds labels[2];
} replace_entry;

typedef enum symbol_table_entry_type {
    entry_code,
    entry_data,
    entry_external,
    entry_unknown
} symbol_table_entry_type;

/* a linked list of symbol table entries */
typedef struct symbol_table_entry {
    struct symbol_table_entry* next;

    /* the name this entry has */
    sds label;

    /* the location in the code or data this entry was seen */
    int code_offset;

    /* where is this entry defined */
    int ic;

    /* the type of this entry */
    symbol_table_entry_type type;

    /* a linked list of replace entries that need to be updated
    when this symbol table entry is resolved */
    replace_entry* replace_list;

    /* is this entry also defined as .entry? */
    int isentry;
} symbol_table_entry;

/* create an entry with default values, add it to the end
   of the symbol table */
symbol_table_entry* make_symbol_table_entry();

/* return the entry that matches the given label or NULL
   if one doesn't exist */
symbol_table_entry* find_symbol_table_entry(sds label);

void destroy_symbol_table();

/* request that a given instruction in the code be updated
   with the correct offsets when the address of label l1 is known */
void append_replace_entry(int offset, int instruction_offset, sds l1, sds l2);

/* iterate over all replacements entries and update their values
   with the correct offset, reporting errors if a symbol table
   entry is missing */
int resolve_replacements();

/* flush the entry and extern information to files from
   the symbol table */
int write_external_entry_files(sds extfile, sds entfile);

#endif
