#!/bin/bash

asm() {
    $TESTDIR/../assembler "$@"
}

function compile() {
    rm -f script.{o,ext,ent}
    cat > script.as
    asm script
    rc=$?

    cat script.o 2>/dev/null || echo 'no .o file'
    if [[ -s script.o ]]; then
        python $TESTDIR/../asobjdump.py script.o
    fi

    for extension in ext ent; do
        if [[ -s script.$extension ]]; then
            echo
            echo "$extension file"
            echo "--- ----"
            echo
            cat script.$extension
        else
            echo "no .$extension file"
        fi
    done

    return $rc
}
