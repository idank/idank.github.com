/* Idan Kamara <idankk86@gmail.com> 300587524 */

#include <signal.h>

#include "binsem.h"

void binsem_init(sem_t *s, int init_val) {
  xchg(s, init_val == 1 ? 1 : 0);
}

int binsem_down(sem_t *s) {
  while (1) {
    sem_t old = xchg(s, 0);
    if (old == 0) {
      // yield
      if (raise(SIGALRM) != 0)
        return -1;
    }
    else
      break;
  }

  return 0;
}

void binsem_up(sem_t *s) {
  xchg(s, 1);
}
