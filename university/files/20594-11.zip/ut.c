/* Idan Kamara <idankk86@gmail.com> 300587524 */

#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>

#include "ut.h"

typedef tid_t ut_size;

typedef struct _ut_table {
  ut_slot threads;
  ut_size size;
  ut_size capacity;
} ut_table;

static ut_table table;
static tid_t curr_thread;

int ut_init(int tab_size) {
  if (tab_size > MAX_TAB_SIZE || tab_size < MIN_TAB_SIZE)
    tab_size = MAX_TAB_SIZE;

  table.capacity = tab_size;
  table.threads = malloc(tab_size * sizeof(ut_slot_t));
  if (table.threads == NULL)
    return SYS_ERR;

  return 0;
}

tid_t ut_spawn_thread(void (*func)(int), int arg) {
  if (table.size == table.capacity)
    return TAB_FULL;

  ut_slot slot = &table.threads[table.size];
  slot->func = func;
  slot->arg = arg;
  if (getcontext(&slot->uc) == -1)
    return SYS_ERR;

  slot->uc.uc_stack.ss_sp = malloc(STACKSIZE);
  slot->uc.uc_stack.ss_size = STACKSIZE;
  makecontext(&slot->uc, (void(*)(void))func, 1, arg);

  return table.size++;
}

unsigned long ut_get_vtime(tid_t tid) {
  if (tid > table.size) {
    printf("bad tid\n");
    return SYS_ERR;
  }

  return table.threads[tid].vtime;
}

static void handler(int signal) {
  if (signal == SIGVTALRM) {
    table.threads[curr_thread].vtime += 100;
  }
  else if (signal == SIGALRM) {
    alarm(1);

    curr_thread += 1;
    curr_thread = curr_thread % table.size;
    setcontext(&table.threads[curr_thread].uc);
  }
  else {
    printf("unexpected signal\n");
    abort();
  }
}

int ut_start(void) {
  struct sigaction sa;
  struct itimerval itv;

  if (table.size == 0) {
    printf("no threads to schedule\n");
    return SYS_ERR;
  }

  sa.sa_flags = SA_RESTART;
  sigfillset(&sa.sa_mask);
  sa.sa_handler = handler;

  itv.it_interval.tv_sec = 0;
  itv.it_interval.tv_usec = 100000;
  itv.it_value = itv.it_interval;

  if (sigaction(SIGALRM, &sa, NULL) < 0 ||
      sigaction(SIGVTALRM, &sa, NULL) < 0 ||
      setitimer(ITIMER_VIRTUAL, &itv, NULL) < 0)
    return SYS_ERR;

  curr_thread = 0;
  alarm(1);

  setcontext(&table.threads[0].uc);

  // can't reach this point
  abort();
}
