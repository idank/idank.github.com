/*
 *    _    _  ____          _____  _____
 *   | |  | |/ __ \   /\   |  __ \|  __ \
 *   | |__| | |  | | /  \  | |__) | |  | |
 *   |  __  | |  | |/ /\ \ |  _  /| |  | |
 *   | |  | | |__| / ____ \| | \ \| |__| |
 *   |_|  |_|\____/_/    \_\_|  \_\_____/
 *
 *             memory allocator
 *
 *          written by Idan Kamara
 */

#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <math.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <fcntl.h>
#include <sys/mman.h>

#include "mtmm.h"

#define MAX_MALLOC_SZ SUPERBLOCK_SIZE / 2
#define HEAPS 10

static void _lock_or_die(pthread_mutex_t *l) {
  if (pthread_mutex_lock(l)) {
    perror(NULL);
    abort();
  }
}

static double f = 0.25;
static int K = 0;

// our heap contains a pointer to a linked list of superblocks
// for each of the 16 size classes
typedef struct heap_t {
  int u;
  int a;

  struct superblock_t *superblocks[16];

  pthread_mutex_t lock;
} heap_t;

typedef struct superblock_t {
  int u;
  size_t class;

  // the heap this superblock belongs to
  struct heap_t *owner;

  // we inline the linked list in the superblock, these are the next and previous
  // superblocks in the current size class
  struct superblock_t *prev, *next;

  // the head and tail of a linked list of free chunks
  struct {
    struct chunk_t *head, *tail;
  } free;

  // mutex used when accessing various fields of a superblock
  pthread_mutex_t lock;
} superblock_t;

typedef struct chunk_t {
  // the amount of bytes following the end of this struct that are
  // used by the user. a user may get a bigger chunk
  // than requested since we round to the nearest power of 2
  size_t size;

  // inlined pointers to the next and prev chunks in the free list, only
  // set when this chunk is part of the free list
  struct chunk_t *prev, *next;

  // the superblock that owns this chunk
  struct superblock_t *owner;

  // a conveinence pointer to the end of this chunk
  void *end;
} chunk_t;

// array of heaps, where heaps[0] is the global heap and
// does not normally serve malloc requests
heap_t heaps[HEAPS];

// execute once initialization function for mtmm. takes care of
// initializing the heaps.
static void _init_mtmm() {
  static int initialized = 0;
  static pthread_mutex_t initialization_mutex = PTHREAD_MUTEX_INITIALIZER;

  if (!initialized) {
    _lock_or_die(&initialization_mutex);

    if (!initialized) {
      for (int i = 0; i < HEAPS; i++) {
        heap_t *heap = &heaps[i];
        memset((void*)heap, 0, sizeof(heap_t));

        if (pthread_mutex_init(&heap->lock, NULL)) {
          perror(NULL);
          abort();
        }
      }

      initialized = 1;
    }

    if (pthread_mutex_unlock(&initialization_mutex)) {
      perror(NULL);
      abort();
    }
  }
}

// mmap an anonymous region of size sz
static void *_mmap_anon(size_t sz) {
  int fd = open("/dev/zero", O_RDWR);
  void *p;

  if (fd == -1) {
    perror(NULL);
    return NULL;
  }

  p = mmap(0, sz, PROT_READ | PROT_WRITE, MAP_PRIVATE, fd, 0);
  close(fd);

  if (p == MAP_FAILED) {
    perror(NULL);
    return NULL;
  }

  return p;
}

// move the superblock sb from heap src to heap dst
static void move_superblock(superblock_t *sb, heap_t *src, heap_t *dst) {
#ifdef NDEBUG
  printf("moving superblock\n");
#endif

  // fix the counters
  src->u -= sb->u;
  dst->u += sb->u;
  src->a -= SUPERBLOCK_SIZE;
  dst->a += SUPERBLOCK_SIZE;

  // remove the superblock from the source heap
  if (src->superblocks[sb->class] == sb) {
    src->superblocks[sb->class] = sb->next;
  }

  if (sb->next) {
      sb->next->prev = sb->prev;
  }
  if (sb->prev) {
      sb->prev->next = sb->next;
  }

  sb->next = sb->prev = NULL;

  // add the superblock to the destination heap
  sb->owner = dst;
  superblock_t *oldhead = dst->superblocks[sb->class];
  dst->superblocks[sb->class] = sb;
  sb->next = oldhead;
  if (oldhead) {
    oldhead->prev = sb;
  }
}

// finds the least full superblock that has a free chunk, starting at sb
static superblock_t *find_least_full(superblock_t *sb) {
  superblock_t *r = NULL;
  for (; sb != NULL; sb = sb->next) {
    if (sb->free.head) {
      if (!r) {
        r = sb;
      }
      else if (sb->u < r->u) {
        r = sb;
      }
    }
  }

  return r;
}

// marks chunk as being used by removing it from the free list
static void claim_chunk(chunk_t *chunk) {
  // fix the counters
  superblock_t *sb = chunk->owner;
  sb->u += chunk->size;
  sb->owner->u += chunk->size;

  // remove chunk from the free list
  chunk_t *prev = chunk->prev;
  if (prev != NULL) {
    prev->next = chunk->next;
  }

  if (chunk->next) {
    chunk->next->prev = prev;
  }

  // update the head and tail of the free list if necessary
  if (sb->free.head == chunk) {
    sb->free.head = chunk->next;
  }
  if (sb->free.tail == chunk) {
    sb->free.tail = prev;
  }

  chunk->next = chunk->prev = NULL;
}

// initialize a region in memory p to be a chunk of size
// also add it to the end of the free list inside sb
static chunk_t *init_chunk(void *p, size_t length, chunk_t *prev, superblock_t *sb) {
  chunk_t *c = (chunk_t*)p;
  c->size = length;
  c->owner = sb;
  c->prev = prev;
  c->end = p + sizeof(chunk_t) + length;

  if (prev) {
    prev->next = c;
  }

  return c;
}

// allocate a new superblock in the class size, add it to heap
static superblock_t *init_superblock(size_t class, heap_t *heap) {
  // ask for some memory
  void *p = _mmap_anon(SUPERBLOCK_SIZE);
  if (p == NULL) {
    return NULL;
  }
  void *end = p + SUPERBLOCK_SIZE;

  superblock_t *sb = (superblock_t*)p;

  sb->owner = heap;
  sb->u = 0;
  sb->class = class;
  if (pthread_mutex_init(&sb->lock, NULL)) {
    perror(NULL);
    abort();
  }

  p += sizeof(superblock_t);
  sb->free.head = (chunk_t*)p;

  // class is 0 zero based -> 0 == allocations up to 2, 1 up to 4
  size_t chunk_length = (size_t)pow(2, class + 1);

  // initialize all chunks in the superblock
  chunk_t *prevc = NULL;
  while (p + sizeof(chunk_t) + chunk_length < end) {
    chunk_t *c = init_chunk(p, chunk_length, prevc, sb);
    p = c->end;

    prevc = c;
  }

  sb->free.tail = prevc;

  // add the superblock to the heap's superblock linked list tail
  if (heap->superblocks[class]) {
    superblock_t *tailsb = heap->superblocks[class];
    while (tailsb->next != NULL) {
      tailsb = tailsb->next;
    }
    tailsb->next = sb;
    sb->prev = tailsb;
  }
  else {
    heap->superblocks[class] = sb;
  }

  return sb;
}

void *malloc(size_t sz) {
  _init_mtmm();

  // we return an unmanaged chunk of memory when the user
  // wants more than half the size of a superblock
  if (sz > MAX_MALLOC_SZ) {
#ifdef NDEBUG
    printf("allocation exceeds half the size of a superblock\n");
#endif

    void *p = _mmap_anon(sz + sizeof(chunk_t));
    if (p == NULL) {
      return NULL;
    }
    chunk_t *chunk = (chunk_t*)p;
    chunk->size = sz;
    chunk->end = p + sz + sizeof(chunk_t);
    // no owner means this chunk doesn't belong to any of the superblocks/heaps
    // and will be reclaimed by the OS when free'ed
    chunk->owner = NULL;

    return p + sizeof(chunk_t);
  }

  // find the heap for this thread (don't choose the global heap)
  // and lock it
  size_t id = ((size_t)pthread_self()) % (HEAPS - 1);
  id++;

  heap_t *heap = &heaps[id];
  _lock_or_die(&heap->lock);

  // find the right size class for this malloc request
  size_t class = 0;
  if (sz > 2) {
      class = (size_t)ceil(log2(sz)) - 1;
  }
  superblock_t *sb = heap->superblocks[class];
  chunk_t *chunk;

  // we check if our heap has any superblocks, and if so take
  // a chunk from the least full superblock that has any
  if (sb != NULL) {
    sb = find_least_full(sb);

    if (sb) {
      chunk = sb->free.head;
    }
  }

  // our heap has no superblocks with enough space, check the global one
  if (sb == NULL || chunk == NULL) {
    heap_t *global_heap = &heaps[0];
    _lock_or_die(&global_heap->lock);

    sb = find_least_full(global_heap->superblocks[class]);
    if (0 && sb) {
      // the global heap has a superblock with enough free space, move it
      // to the current heap
      move_superblock(sb, global_heap, heap);
      chunk = sb->free.head;
    }
    pthread_mutex_unlock(&global_heap->lock);

    // still no superblock, allocate a new one
    if (sb == NULL) {
      sb = init_superblock(class, heap);
      // there was a problem allocating the superblock,
      // return NULL to the user
      if (sb == NULL) {
        return NULL;
      }

      // take the first free chunk from the new superblock
      chunk = sb->free.head;
    }
  }

  assert(chunk);
  assert(sz <= chunk->size);

  claim_chunk(chunk);

  pthread_mutex_unlock(&heap->lock);

  return (void*)chunk + sizeof(chunk_t);
}

void free(void *p) {
  _init_mtmm();

  // no-op for NULL pointers
  if (p == NULL) {
    return;
  }

  // chunk precedes the given pointer, do some santiy checks on it
  chunk_t *chunk = (chunk_t*)(p - sizeof(chunk_t));
  assert(chunk->size > 0);
  assert(chunk->end != NULL);

  // check for an unmanaged chunk
  if (chunk->owner == NULL) {
    if (munmap(p, chunk->end - p) < 0) {
      perror(NULL);
    }

    return;
  }

  // this chunk shouldn't have any prev/next pointers
  // since it's not in the free list
  assert(chunk->next == NULL);
  assert(chunk->prev == NULL);

  // start freeing this chunk, lock heap and superblock
  // first
  superblock_t *sb = chunk->owner;
  heap_t *heap = sb->owner;

  _lock_or_die(&heap->lock);
  _lock_or_die(&sb->lock);

  // update counters
  heap->u -= chunk->size;
  sb->u -= chunk->size;

  // move chunk to free list
  if (sb->free.head == NULL) {
    assert(sb->free.tail == NULL);

    sb->free.head = sb->free.tail = chunk;
  }
  else {
    assert(sb->free.tail != NULL);

    // add it to the end of the free list
    chunk->prev = sb->free.tail;
    sb->free.tail->next = chunk;
    sb->free.tail = chunk;
  }

  // if we're in the global heap, don't bother checking
  // for the emptiness threshold
  if (heap == &heaps[0]) {
    goto unlock;
  }

  // should we move a superblock from our heap to the global one?
  if (heap->u < heap->a - (K * SUPERBLOCK_SIZE) &&
      heap->u < (1 - f) * heap->a) {
#ifdef NDEBUG
    printf("emptiness threshold\n");
#endif

    // find the emptiest superblock in the current size class
    superblock_t *mostemptysb = heap->superblocks[sb->class];
    for (superblock_t *t = mostemptysb; t != NULL; t = t->next) {
      if (t->u < mostemptysb->u) {
        mostemptysb = t;
      }
    }

    // we're about to touch the global heap, take a lock first
    _lock_or_die(&heaps[0].lock);

    // move the superblock to the global heap
    move_superblock(mostemptysb, heap, &heaps[0]);
    pthread_mutex_unlock(&heaps[0].lock);
  }

unlock:
    pthread_mutex_unlock(&sb->lock);
    pthread_mutex_unlock(&heap->lock);
}

void *realloc(void *p, size_t sz) {
  _init_mtmm();

  chunk_t *chunk = (chunk_t*)(p - sizeof(chunk_t));

  // nothing to do if the requested size is smaller than our chunk
  if (sz <= chunk->size) {
    return p;
  }
  else {
    // 1) allocate enough space
    // 2) copy the old data over
    // 3) reclaim the old space
    void *newp = malloc(sz);
    if (newp == NULL) {
      return NULL;
    }

    memcpy(newp, p, chunk->size);
    free(p);

    return newp;
  }
}
