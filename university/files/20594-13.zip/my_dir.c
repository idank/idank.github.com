#include <assert.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <linux/ext2_fs.h>
#include <string.h>

#define FLOPPY "/dev/fd0"
#define MYEXT2 "/tmp/.myext2"

#define BASE_OFFSET 1024
#define BLOCK_OFFSET(block) (BASE_OFFSET + (block - 1) * block_size)

static unsigned int block_size = 0;

// reads out block_no into buffer
void read_block(int fd, int block_no, char* buffer) {
  lseek(fd, BLOCK_OFFSET(block_no), SEEK_SET);
  read(fd, buffer, block_size);
}

// return the inode of the direntry with name, -1 if not found
int find_name_in_direntry(int fd, struct ext2_inode* inode, char* name) {
  char *buffer = malloc(block_size);
  for (int i = 0; i < inode->i_blocks; i++) {
    read_block(fd, inode->i_block[i], buffer);

    struct ext2_dir_entry_2 *dirent;
    char* ptr = buffer;
    while (ptr + sizeof(struct ext2_dir_entry_2) < buffer + block_size) {
      dirent = (struct ext2_dir_entry_2 *)ptr;

      if (dirent->inode == 0) {
        break;
      }

      if (dirent->name_len == strlen(name) &&
          strncmp(dirent->name, name, dirent->name_len) == 0) {
        return dirent->inode;
      }

      ptr += dirent->rec_len;
    }
  }

  free(buffer);

  return -1;
}

// pretty print the inode with the given name
void print_inode(struct ext2_inode* inode, const char* name, int len) {
  time_t t = inode->i_mtime;
  char tbuf[100];
  strftime(tbuf, 100, "%d-%h-%G %T", localtime(&t));

  printf("%s %.*s\n", tbuf, len, name);
}

void read_inode(int fd, struct ext2_super_block* super, struct ext2_group_desc* group,
                int inode_no, struct ext2_inode* inode) {
  int group_no = inode_no/super->s_inodes_per_group;
  int inode_offset = (inode_no - group_no * super->s_inodes_per_group -1)
   * sizeof(struct ext2_inode);

  lseek(fd, BLOCK_OFFSET(group[group_no].bg_inode_table) + inode_offset, SEEK_SET);
  read(fd, inode, sizeof(struct ext2_inode));
}

// reads the root inode from the floppy, returning the floppy's fd
int get_root_inode(struct ext2_super_block* super, struct ext2_group_desc* group,
                   struct ext2_inode* root_inode) {
  int fd;

  fd = open(FLOPPY, O_RDONLY);
  if (fd < 0) {
    perror(FLOPPY);
    exit(1);
  }

  // seek to the superblock and read it
  lseek(fd, BASE_OFFSET, SEEK_SET);
  read(fd, super, sizeof(struct ext2_super_block));

  if(super->s_magic != EXT2_SUPER_MAGIC){
    fprintf(stderr, "Not an Ext2 filesystem!\n");
    exit(1);
  }

  block_size = 1024 << super->s_log_block_size;

  // now onto reading the group descriptor, seek to the first descriptor and read it
  lseek(fd, BASE_OFFSET + block_size, SEEK_SET);
  read(fd, group, sizeof(struct ext2_group_desc));

  // read the root inode
  read_inode(fd, super, group, 2, root_inode);

  return fd;
}

// prints the contents of the directory pointed to by path
// returns 0 if it doesn't exist, 1 on success
int print_dir(const char *path) {
  struct ext2_inode root_inode, curr_inode;
  struct ext2_super_block super;
  struct ext2_group_desc group;

  int found = 1;
  int floppyfp = get_root_inode(&super, &group, &root_inode);

  char *mutable = malloc(strlen(path));
  strcpy(mutable, path);
  char *part = strtok(mutable, "/");
  curr_inode = root_inode;
  int part_inode = -1;

  if (part != NULL) {
    while (part != NULL) {
      part_inode = find_name_in_direntry(floppyfp, &curr_inode, part);
      if (part_inode > 0) {
        read_inode(floppyfp, &super, &group, part_inode, &curr_inode);
      }
      else {
        break;
      }

      part = strtok(NULL, "/");
    }

    // current part not found
    if (part_inode < 0) {
      found = 0;
      goto cleanup;
    }
  }

  assert(part == NULL);
  if (curr_inode.i_mode & 0x4000) {
    char *buffer = malloc(block_size);

    for (int i = 0; i < curr_inode.i_blocks; i++) {
      read_block(floppyfp, curr_inode.i_block[i], buffer);

      struct ext2_dir_entry_2 *dirent;
      char* ptr = buffer;
      while (ptr + sizeof(struct ext2_dir_entry_2) < buffer + block_size) {
        dirent = (struct ext2_dir_entry_2 *)ptr;
        if (dirent->inode == 0) {
          break;
        }

        struct ext2_inode t_inode;
        read_inode(floppyfp, &super, &group, dirent->inode, &t_inode);
        print_inode(&t_inode, dirent->name, dirent->name_len);

        ptr += dirent->rec_len;
      }
    }

    free(buffer);
  }
  else {
    fprintf(stderr, "error: %s is a file\n", path);
    found = 0;
  }

cleanup:
  free(mutable);
  close(floppyfp);

  return found;
}

int main(int argc, char *argv[]) {
  int rc = 0;

  FILE *myext2 = fopen(MYEXT2, "r");
  char *path;
  if (myext2 == NULL) {
    rc = 1;
    myext2 = fopen(MYEXT2, "w");
    if (myext2 == NULL || fwrite("/", 1, 1, myext2) != 1) {
      // can't open the file for writing, give up
      perror(MYEXT2);
      return rc;
    }

    path = "/";
  }
  else {
    fseek(myext2, 0L, SEEK_END);
    unsigned long len = (unsigned long)ftell(myext2);
    path = malloc(len + 1);
    path[len] = 0;
    fseek(myext2, 0L, SEEK_SET);
    if (fread(path, 1, len, myext2) < len) {
      perror(MYEXT2);
      return 1;
    }
  }

  if (!print_dir(path)) {
    rc = 1;
    print_dir("/");
  }

  return rc;
}
