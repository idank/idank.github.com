you can see the changes I've made to the code in the changes.diff file in each directory (it's in git diff format).
